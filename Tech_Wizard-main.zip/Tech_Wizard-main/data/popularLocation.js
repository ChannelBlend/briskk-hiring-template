const popularLocations = [
    // {
    //     storeName: 'Kormangala, Bangalore',
    //     latitude: '12.937350799752029',
    //     longitude: '77.62361608137164',
    //     link: 'https://briskk.one/?location=Kormangala-Bangalore',
    // },
    {
        storeName: 'Jaynagar, Bangalore',
        latitude: '12.9300439',
        longitude: '77.5861519',
        link: 'https://briskk.one/?location=Jaynagar-Bangalore',
    },
    {
        storeName: 'HSR Layout, Bangalore',
        latitude: '12.9128125',
        longitude: '77.6519375',
        link: 'https://briskk.one/',
    },
    {
        storeName: 'Indiranagar , Bangalore',
        latitude: '12.962512252414461',
        longitude: '77.64185114244083',
        link: 'https://briskk.one/?location=Indiranagar+-Bangalore',
    },
]

export default popularLocations
